#!/usr/bin/env bash
set -euo pipefail

CONTAINER_NAME="${CONTAINER_NAME:-aiworld-postgres}"
DB_NAME="${DB_NAME:-aiworld}"
DB_USER="${DB_USER:-aiworld}"
OUTPUT_DIR="${OUTPUT_DIR:-/opt/aiworld/server/backups}"
RETENTION_DAYS="${RETENTION_DAYS:-7}"

mkdir -p "$OUTPUT_DIR"

if ! docker ps --format '{{.Names}}' | grep -qx "$CONTAINER_NAME"; then
  echo "Postgres container '$CONTAINER_NAME' is not running" >&2
  exit 1
fi

timestamp="$(date +%Y%m%d_%H%M%S)"
output_file="$OUTPUT_DIR/${DB_NAME}_${timestamp}.dump"
checksum_file="$output_file.sha256"

docker exec "$CONTAINER_NAME" sh -lc "pg_dump -U '$DB_USER' -d '$DB_NAME' -Fc" > "$output_file"
sha256sum "$output_file" > "$checksum_file"

find "$OUTPUT_DIR" -type f \( -name '*.dump' -o -name '*.sha256' \) -mtime "+$RETENTION_DAYS" -delete

echo "Backup created: $output_file"