#!/usr/bin/env bash
# ============================================================================
# validate-migrations.sh
# Run in CI or manually to verify Prisma migrations apply cleanly
# against a fresh PostgreSQL instance.
#
# Usage:
#   DATABASE_URL='postgresql://...' bash scripts/validate-migrations.sh
#
# In CI this is invoked automatically in the backend-unit-tests job.
# ============================================================================

set -euo pipefail

echo "==> Checking Prisma schema validity..."
npx prisma validate

echo "==> Generating Prisma Client..."
npx prisma generate

echo "==> Applying all migrations (prisma migrate deploy)..."
npx prisma migrate deploy

echo "==> Checking for migration drift (prisma migrate diff)..."
DIFF_OUTPUT=$(npx prisma migrate diff \
  --from-migrations ./prisma/migrations \
  --to-schema-datamodel ./prisma/schema.prisma \
  --exit-code 2>&1 || true)

if [ -n "$DIFF_OUTPUT" ]; then
  echo "⚠️  Schema drift detected — run 'npx prisma migrate dev' to generate a new migration:"
  echo "$DIFF_OUTPUT"
  exit 1
fi

echo "✅ All migrations applied successfully — schema is in sync."
