# AI-World P0 运维基线 Runbook

## 1) 监控与告警

### 启动观测栈

```bash
cd server
npm run ops:observability:up
```

- Prometheus: `http://localhost:9090`
- Alertmanager: `http://localhost:9093`
- API metrics: `http://localhost:3000/metrics`

### 关键告警规则

已配置在 `ops/prometheus/alert.rules.yml`：
- `AIWorldApiDown`: API 无法被采集 1 分钟。
- `AIWorldHigh5xxRate`: 5 分钟窗口 5xx 比例 > 3%。
- `AIWorldP95LatencyHigh`: P95 延迟持续高于 800ms。
- `AIWorldUnhandledExceptionsSpike`: 5 分钟内未处理异常增长 > 10。

### 告警接收

默认使用 webhook：
- 配置文件：`ops/alertmanager/alertmanager.yml`
- 默认目标：`http://host.docker.internal:5001/alerts`

你可以替换为企业微信/钉钉/Slack 告警网关。

## 2) 日志基线

服务日志为 JSON 结构化输出，包含：
- `requestId`
- `method`
- `path`
- `statusCode`
- `durationMs`
- `ip`
- `userAgent`

日志级别策略：
- `2xx/3xx` => `info`
- `4xx` => `warn`
- `5xx` => `error`

## 3) 异常追踪

### 启用 Sentry

在 `server/.env.local` 配置：

```dotenv
SENTRY_DSN="<your_dsn>"
SENTRY_TRACES_SAMPLE_RATE="0.1"
APP_VERSION="1.0.0"
```

未配置 `SENTRY_DSN` 时，服务自动降级为 no-op，不影响业务。

## 4) 健康检查

- `GET /health`: DB + Redis 连通性健康检查
- `GET /ready`: 进程就绪检查
- `GET /metrics`: Prometheus 抓取指标

## 5) 备份与恢复演练

### 执行备份

```bash
cd server
npm run ops:backup
```

输出：`server/backups/*.dump` + SHA256。

### 执行恢复（默认恢复最新备份）

```bash
cd server
npm run ops:restore
```

恢复脚本会：
1. 终止目标库连接
2. Drop + Recreate 数据库
3. `pg_restore` 导入
4. 校验 `public` schema 表数量

## 6) 演练频率（P0 建议）

- 每日：健康检查/告警链路巡检
- 每周：随机抽样恢复演练（至少一次）
- 每月：全量恢复演练 + 告警阈值复盘

## 7) 值班处置流程

1. 告警触发后 5 分钟内确认。
2. 先看 `AIWorldApiDown` 与 `/health`。
3. 再看 5xx/延迟异常趋势。
4. 如出现错误洪峰，按 `requestId` 回溯日志。
5. 如数据风险，优先执行恢复预演并记录结果。
