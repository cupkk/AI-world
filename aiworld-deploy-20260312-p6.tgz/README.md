# AI-World

AI-World 是一个面向学习者、专家和企业负责人的 AI 社区平台。仓库包含前端 SPA、NestJS API、异步 worker、知识库处理链路，以及面向 staging / production 的 Docker Compose 运维配置。

## Stack

- Frontend: Vite + React + TypeScript
- Backend: NestJS + Prisma + PostgreSQL + Redis
- Worker: Python task runner for knowledge base processing
- Observability: Prometheus + Alertmanager

## Repository Layout

- `src/`: 前端应用
- `server/`: API、Prisma、Docker Compose、运维脚本
- `worker/`: 知识库异步处理
- `tests/e2e/`: 本地 mocked Playwright E2E
- `tests/live/`: staging / production 真实环境回归

## Local Development

### Frontend

```bash
npm install
npm run dev
```

默认地址：`http://localhost:5173`

### Backend

```bash
cd server
npm install
cp .env.example .env.local
npx prisma generate
npx prisma migrate dev
npm run start:dev
```

默认地址：`http://localhost:3000`

### Worker

```bash
cd worker
pip install -r requirements.txt
python -m celery_app
```

## Environment Files

本地开发继续使用：

- 根目录 `.env.example`
- `server/.env.example`

部署环境使用独立文件，不要混用本地样板：

- 前端构建参数：`.env.production.example`、`.env.staging.example`
- API/worker 运行时：`server/.env.production.example`、`server/.env.staging.example`

生产和 staging 都必须满足以下约束：

- `REQUIRE_OSS=true`
- `REQUIRE_SMTP=true`
- `REQUIRE_LLM=true`
- `ENABLE_DEMO_INVITES=false`
- `SEED_INCLUDE_DEMO_DATA=false`
- 前端构建显式关闭：
  - `VITE_ENABLE_DEMO_MODE=false`
  - `VITE_ALLOW_DEMO_PREFILL=false`

## Testing

### Frontend

```bash
npm exec tsc --noEmit
npm run build
npx playwright test --project=chromium
```

本地 mocked E2E 现在默认启用 fail-fast：任何未显式 mock 的 `/api/**` 请求都会直接让测试失败。

### Backend

```bash
cd server
npm exec tsc --noEmit
npm test -- --runInBand
```

### Live Smoke

生产只跑 smoke，不跑 mutation：

```bash
set PRODUCTION_BASE_URL=https://ai-world.asia
set PLAYWRIGHT_BASE_URL=https://ai-world.asia
set LIVE_ADMIN_EMAIL=<admin-email>
set LIVE_ADMIN_PASSWORD=<admin-password>
set LIVE_LEARNER_EMAIL=<learner-email>
set LIVE_LEARNER_PASSWORD=<learner-password>
set LIVE_EXPERT_EMAIL=<expert-email>
set LIVE_EXPERT_PASSWORD=<expert-password>
set LIVE_ENTERPRISE_EMAIL=<enterprise-email>
set LIVE_ENTERPRISE_PASSWORD=<enterprise-password>
npx playwright test -c playwright.live.config.ts tests/live/prod-smoke.spec.ts
```

staging 的写路径回归只允许在非生产地址执行：

```bash
set STAGING_BASE_URL=https://staging.ai-world.asia
set PLAYWRIGHT_BASE_URL=https://staging.ai-world.asia
set LIVE_ALLOW_MUTATIONS=1
set LIVE_ADMIN_EMAIL_STAGING=<admin-email>
set LIVE_ADMIN_PASSWORD_STAGING=<admin-password>
set LIVE_LEARNER_EMAIL_STAGING=<learner-email>
set LIVE_LEARNER_PASSWORD_STAGING=<learner-password>
set LIVE_EXPERT_EMAIL_STAGING=<expert-email>
set LIVE_EXPERT_PASSWORD_STAGING=<expert-password>
set LIVE_ENTERPRISE_EMAIL_STAGING=<enterprise-email>
set LIVE_ENTERPRISE_PASSWORD_STAGING=<enterprise-password>
npx playwright test -c playwright.live.config.ts tests/live/staging-mutation.spec.ts
```

## Deployment Model

当前仓库采用单台 ECS + Docker Compose，但已经拆成三套职责：

- `server/docker-compose.prod.yml`: production 应用栈
- `server/docker-compose.staging.yml`: staging 应用栈
- `server/ops/docker-compose.edge.yml`: 同机 edge nginx，负责 `ai-world.asia` / `www.ai-world.asia` / `staging.ai-world.asia`
- `server/ops/docker-compose.observability.yml`: Prometheus / Alertmanager

公开暴露面现在只保留：

- `/health`
- `/ready`

`/metrics` 只允许 Prometheus 通过内部 Docker 网络抓取，不再从公网暴露。

## Deployment Scripts

在服务器 `server/` 目录下执行：

```bash
chmod +x ./scripts/*.sh
./scripts/ensure-docker-networks.sh
REGISTRY=<registry> IMAGE_TAG=<tag> ./scripts/deploy-stack.sh staging
REGISTRY=<registry> IMAGE_TAG=<tag> ./scripts/deploy-stack.sh production
REGISTRY=<registry> ./scripts/rollback-stack.sh production <previous-tag>
```

## GitHub Actions

仓库现在按三段流水线运行：

- `ci.yml`: PR / push 校验，只做类型检查、构建、单测、mocked E2E、Docker build check
- `deploy-staging.yml`: `main` 自动部署 staging，部署后运行 live smoke
- `promote-production.yml`: 手动输入已经通过 staging 的镜像 tag，提升到 production，部署后自动执行 `/ready`、`/health` 和 production smoke

生产发布不允许在生产机临时本地重构建。

## Shared Contracts

- 共享状态与枚举定义：`server/src/common/contracts.ts`
- 前端复用入口：`src/lib/contracts.ts`

新增状态值或序列化格式时，必须先改共享契约，再改前后端调用方。

## Assistant Contract

`POST /api/assistant/recommend`

- 成功：保持现有推荐结构
- 失败：统一返回 `503`
- 机器码：`errorCode: "ASSISTANT_UNAVAILABLE"`

前端不会再显示“切换到本地推荐模式”之类的伪降级文案。

## External Prerequisites

以下事项不在仓库内自动完成，部署前需要云侧权限：

- ECS 固定 EIP
- DNS:
  - `ai-world.asia`
  - `www.ai-world.asia`
  - `staging.ai-world.asia`
- 证书签发与续期，需覆盖 production + staging
- SMTP / OSS / LLM 凭据轮换

详细运维流程见 [docs/运维手册.md](docs/%E8%BF%90%E7%BB%B4%E6%89%8B%E5%86%8C.md)。
